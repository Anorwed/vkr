import os
import asyncio
import logging
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.exceptions import TelegramBadRequest
from aiogram.types import FSInputFile
from google.genai import types as sdk_types  # Нужно для ручного управления историей
from dotenv import load_dotenv

# Импорт твоих модулей
try:
    from core.ai import get_gemini_response
    from core.tools import create_chemistry_docx
except ImportError as e:
    print(f"Ошибка импорта: {e}. Убедись, что папка core и файлы ai.py/tools.py на месте.")
    exit(1)

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

load_dotenv()

# Инициализация
bot = Bot(token=os.getenv("BOT_TOKEN"))
dp = Dispatcher()
DOWNLOAD_DIR = "downloads"
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

# Хранилище истории: {user_id: [список объектов sdk_types.Content]}
user_history = {}

# --- ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ---

def get_system_prompt():
    prompt_path = "system.txt"
    base = "Ты эксперт-учитель химии. Твоя задача — помогать ученикам объяснять сложные темы и решать задачи."
    if os.path.exists(prompt_path):
        try:
            with open(prompt_path, "r", encoding="utf-8") as f:
                base = f.read()
        except Exception as e:
            logger.error(f"Ошибка чтения system.txt: {e}")
    
    instruction = (
        "\n\n[SYSTEM]: Если пользователь просит создать документ, файл, отчет или конспект, "
        "обязательно начни свой ответ СТРОГО с тега [DOCX]. Ты помнишь контекст диалога."
    )
    return base + instruction

def split_text(text, max_length=4000):
    if not text: return ["Пустой ответ от ИИ."]
    parts = []
    while len(text) > max_length:
        split_at = text.rfind('\n', 0, max_length) or max_length
        parts.append(text[:split_at])
        text = text[split_at:].lstrip()
    parts.append(text)
    return parts

async def safe_reply(message: types.Message, text: str):
    """Логика разделения текста и генерации DOCX"""
    if not text: return

    # Если ИИ решил создать документ
    if text.strip().startswith("[DOCX]"):
        clean_text = text.replace("[DOCX]", "").strip()
        filename = f"chemistry_work_{message.from_user.id}.docx"
        
        try:
            path = create_chemistry_docx(clean_text, filename)
            if os.path.exists(path):
                await message.answer_document(FSInputFile(path), caption="📄 Документ готов!")
                os.remove(path)
                return 
        except Exception as e:
            logger.error(f"Docx error: {e}")
            await message.answer("⚠️ Ошибка создания DOCX, отправляю текст:")
            text = clean_text

    # Обычная отправка (разбиение на части)
    for part in split_text(text):
        if not part.strip(): continue
        try:
            await message.answer(part, parse_mode="Markdown")
        except TelegramBadRequest:
            await message.answer(part, parse_mode=None)
        await asyncio.sleep(0.5)

# --- ХЕНДЛЕРЫ ---

@dp.message(Command("start"))
async def start_cmd(message: types.Message):
    # При /start очищаем историю пользователя
    user_history[message.from_user.id] = []
    await message.answer(
        "👋 Контекст очищен! Я готов к новому уроку.\n"
        "Можешь прислать фото задачи или попросить составить конспект в Word."
    )

@dp.message(F.photo | F.document)
async def handle_files(message: types.Message):
    await bot.send_chat_action(message.chat.id, "upload_document")
    uid = message.from_user.id
    if uid not in user_history: user_history[uid] = []

    file_id = message.photo[-1].file_id if message.photo else message.document.file_id
    ext = ".jpg" if message.photo else os.path.splitext(message.document.file_name)[1]
    
    file_path = os.path.join(DOWNLOAD_DIR, f"{file_id}{ext}")
    await bot.download_file((await bot.get_file(file_id)).file_path, file_path)
    
    user_query = message.caption or "Проанализируй файл"
    
    response, updated_history = await get_gemini_response(
        user_query, 
        file_path, 
        get_system_prompt(),
        user_history[uid]
    )
    
    # Ручное обновление истории для надежности
    if len(updated_history) <= len(user_history[uid]):
        updated_history.append(sdk_types.Content(role="user", parts=[sdk_types.Part.from_text(text=user_query)]))
        updated_history.append(sdk_types.Content(role="model", parts=[sdk_types.Part.from_text(text=response)]))

    user_history[uid] = updated_history[-10:] # Ограничение 10 сообщений
    await safe_reply(message, response)
    
    if os.path.exists(file_path):
        os.remove(file_path)

@dp.message(F.text)
async def handle_text(message: types.Message):
    await bot.send_chat_action(message.chat.id, "typing")
    uid = message.from_user.id
    if uid not in user_history: user_history[uid] = []

    response, updated_history = await get_gemini_response(
        message.text, 
        None, 
        get_system_prompt(), 
        user_history[uid]
    )
    
    # Ручное обновление истории, если SDK вернул старый список
    if len(updated_history) <= len(user_history[uid]):
        updated_history.append(sdk_types.Content(role="user", parts=[sdk_types.Part.from_text(text=message.text)]))
        updated_history.append(sdk_types.Content(role="model", parts=[sdk_types.Part.from_text(text=response)]))

    user_history[uid] = updated_history[-10:]
    await safe_reply(message, response)

# --- ЗАПУСК ---

async def main():
    logger.info("Бот запущен...")
    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()

if __name__ == "__main__":
    asyncio.run(main())
