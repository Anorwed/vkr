import os
from google import genai
from google.genai import types
from dotenv import load_dotenv

load_dotenv()

client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))
MODEL_ID = "gemini-2.5-flash" 

async def get_gemini_response(text: str, file_path: str = None, system_prompt: str = "", history=None):
    try:
        if history is None:
            history = []

        # Создаем чат-сессию
        chat = client.chats.create(
            model=MODEL_ID,
            config=types.GenerateContentConfig(
                system_instruction=system_prompt,
                temperature=0.7,
            ),
            history=history
        )

        # Подготавливаем части сообщения
        parts = []
        if text:
            parts.append(types.Part.from_text(text=text))
        
        if file_path and os.path.exists(file_path):
            mime_type = "application/pdf" if file_path.endswith('.pdf') else "image/jpeg"
            with open(file_path, "rb") as f:
                parts.append(types.Part.from_bytes(data=f.read(), mime_type=mime_type))

        # Отправляем сообщение
        response = chat.send_message(parts)
        
        # ВАЖНО: В новых версиях SDK история может быть доступна так:
        # Если chat.history недоступен, мы берем историю из объекта чата вручную
        current_history = chat.history if hasattr(chat, 'history') else history
        
        # Если мы отправили файл, в историю добавится только текст (для экономии места)
        # Но SDK обычно делает это сам.
        
        return response.text, current_history
        
    except Exception as e:
        print(f"AI Error: {e}")
        # Если произошла ошибка, возвращаем старую историю, чтобы бот не «забыл» всё
        return f"Ошибка ИИ: {str(e)}", history
