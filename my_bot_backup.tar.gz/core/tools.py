import os
import re
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

def set_font_style(run, bold=False, italic=False):
    """Применяет шрифт Times New Roman 12 и стили начертания"""
    run.font.name = 'Times New Roman'
    # Костыль для корректного отображения шрифта в Word
    run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Times New Roman')
    run.font.size = Pt(12)
    run.bold = bold
    run.italic = italic

def parse_markdown_to_paragraph(paragraph_obj, text):
    """Парсит текст с **жирным** и _курсивом_ в один абзац Word"""
    # Регулярное выражение для поиска **bold**, _italic_ или обычного текста
    parts = re.split(r'(\*\*.*?\*\*|_.*?_)', text)
    for part in parts:
        if part.startswith('**') and part.endswith('**'):
            run = paragraph_obj.add_run(part[2:-2])
            set_font_style(run, bold=True)
        elif part.startswith('_') and part.endswith('_'):
            run = paragraph_obj.add_run(part[1:-1])
            set_font_style(run, italic=True)
        else:
            run = paragraph_obj.add_run(part)
            set_font_style(run)

def create_chemistry_docx(content: str, filename: str):
    doc = Document()
    
    # Глобальные настройки стиля
    style = doc.styles['Normal']
    style.font.name = 'Times New Roman'
    style.font.size = Pt(12)

    lines = content.split('\n')
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        
        if not line:
            i += 1
            continue

        # 1. Обработка заголовков
        if line.startswith('###'):
            text = line.lstrip('#').strip()
            p = doc.add_heading('', level=2)
            run = p.add_run(text)
            set_font_style(run, bold=True)
            i += 1

        # 2. Обработка таблиц
        elif line.startswith('|'):
            # Собираем все строки таблицы
            table_data = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                if '---' not in lines[i]: # Пропускаем разделительную строку |---|
                    cells = [c.strip() for c in lines[i].split('|') if c.strip()]
                    table_data.append(cells)
                i += 1
            
            if table_data:
                table = doc.add_table(rows=len(table_data), cols=len(table_data[0]))
                table.style = 'Table Grid'
                for row_idx, row_cells in enumerate(table_data):
                    for col_idx, cell_text in enumerate(row_cells):
                        cell = table.cell(row_idx, col_idx)
                        # Очищаем ячейку и парсим маркдаун внутри неё
                        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                        parse_markdown_to_paragraph(cell.paragraphs[0], cell_text)
        
        # 3. Обычный текст
        else:
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            parse_markdown_to_paragraph(p, line)
            i += 1

    file_path = os.path.join("downloads", filename)
    doc.save(file_path)
    return file_path
